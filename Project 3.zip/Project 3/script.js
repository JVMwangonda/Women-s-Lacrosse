
document.addEventListener('DOMContentLoaded', function() {
  fetch('lacrosseData.json')
    .then(response => response.json())
    .then(data => {
      // Populate History Section
      const historySection = document.getElementById('history');
      data.history.forEach(item => {
        const historyItem = document.createElement('div');
        historyItem.innerHTML = `<h3>${item.title}</h3><p>${item.content}</p>`;
        historySection.appendChild(historyItem);
      });

      // Populate How to Play Section
      const howToPlaySection = document.getElementById('how-to-play');
      data.howToPlay.forEach(item => {
        const playItem = document.createElement('div');
        playItem.innerHTML = `<h3>${item.step}</h3><p>${item.description}</p>`;
        howToPlaySection.appendChild(playItem);
      });

      // Populate Game Flow Section
      const gameFlowSection = document.getElementById('game-flow');
      data.gameFlow.forEach(item => {
        const flowItem = document.createElement('div');
        flowItem.innerHTML = `<p>${item.description}</p>`;
        gameFlowSection.appendChild(flowItem);
      });

      // Populate Personal Experience Section
      const personalExperienceSection = document.getElementById('personal-experience');
      data.personalExperience.forEach(item => {
        const experienceItem = document.createElement('div');
        experienceItem.innerHTML = `<h3>${item.title}</h3><p>${item.description}</p>`;
        personalExperienceSection.appendChild(experienceItem);
      });
    })
    .catch(error => console.error('Error fetching local data:', error));
});
